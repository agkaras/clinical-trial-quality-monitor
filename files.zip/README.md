# Ten folder zawiera lokalny cache danych z ClinicalTrials.gov API.
# Cache (trials_cache.rds) jest wykluczony z repozytorium (.gitignore).
# Zostanie wygenerowany automatycznie przy pierwszym uruchomieniu aplikacji.
